PushPopView written by TTung
